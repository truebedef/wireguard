```markdown
# File Content Extractor API

A robust, platform-agnostic API for extracting and summarizing content from various file types using FastAPI and a local Meta-Llama-3-8B-Instruct-GGUF model via LM Studio.

## Features
- Supports `.pdf`, `.ppt`, `.pptx`, `.doc`, `.docx`, `.txt`, `.eml`, `.jpg`, `.jpeg`, `.png`, `.bmp`, and `.tiff` files.
- Extracts text content and metadata (file size, creation/modification dates).
- Generates 10-bullet-point summaries using a local LLM.
- Multithreaded processing for performance.
- Comprehensive error handling with detailed diagnostics.
- Cross-platform compatibility (Windows, macOS, Linux).
- Configurable via `config.yaml`.

## Prerequisites
- **Python 3.8+**: Required for running the API.
- **LM Studio**: Must be installed and running with the Meta-Llama-3-8B-Instruct-GGUF model loaded.
- **Tesseract OCR**: Optional, for processing image files (`.jpg`, `.jpeg`, `.png`, `.bmp`, `.tiff`).
- **Git**: Optional, for cloning the repository.
- Internet connection for downloading dependencies and Tesseract (during setup).

## 🚀 Quick Start

Choose **one** of the following setup methods based on your system:

- **If you already have Python 3.6+ installed:**
  ```bash
  python3 bootstrap.py  # Linux/macOS
  python bootstrap.py   # Windows
  ```
- **If you do NOT have Python installed or want automatic system-level dependency installation:**
  - **Linux/macOS:**
    ```bash
    bash setup.sh
    ```
  - **Windows:**
    - Run `setup.bat` (Command Prompt) or `setup.ps1` (PowerShell)

---

## Setup (Detailed)

The File Content Extractor API supports Windows, macOS, and Linux. You can use the universal `bootstrap.py` Python script or the OS-specific setup scripts provided in this repository.

### Universal Python Bootstrapper
If you have Python 3.6+ already installed, simply run:
```bash
python3 bootstrap.py  # Linux/macOS
python bootstrap.py   # Windows
```
This will:
- Attempt to install system dependencies (git, python, pip, tesseract) using your OS package manager if possible
- Create and activate a Python virtual environment
- Install all Python dependencies from `requirements.txt`
- Print clear instructions for any remaining manual steps

### OS-Specific Setup Scripts
If you do **not** have Python installed, or want to ensure all system dependencies are handled automatically:
- **Linux/macOS:**
  ```bash
  chmod +x setup.sh
  ./setup.sh
  ```
  (Or just: `bash setup.sh`)

- **Windows:**
  - Run `setup.bat` (for Command Prompt)
  - Or run `setup.ps1` (for PowerShell)

These scripts will attempt to install Python, pip, git, tesseract, and all other requirements for your platform.

> **Tip:** If none of the scripts can install Python automatically, please install Python 3.8+ manually from [python.org](https://www.python.org/downloads/) or your OS package manager, then re-run `bootstrap.py`.

---

### Step 2: Install LM Studio
1. Download LM Studio from `https://lmstudio.ai/` and install it.
2. Open LM Studio and download the **Meta-Llama-3-8B-Instruct-GGUF** model.
3. Load the model in LM Studio.
4. Start the local server:
   - Go to the "Local Server" tab in LM Studio.
   - Ensure the server is running (default port: `1234`).
   - Note the host/port if different from `http://localhost:1234` (e.g., `http://127.0.0.1:1234`).
5. Test the server:
   ```bash
   curl http://localhost:1234/v1/chat/completions -H "Content-Type: application/json" -d '{"model": "Meta-Llama-3-8B-Instruct-GGUF", "messages": [{"role": "user", "content": "Test"}]}'
   ```
   If this fails, check the port or restart LM Studio.

### Step 3: Clone the Repository (Optional)
If you have Git installed, clone the repository:
```bash
git clone <repository-url>
cd project
```
Alternatively, download and extract the project files manually.

### Step 4: Install Dependencies
Run the platform-specific setup script to create a virtual environment and install Python dependencies.

- **Linux/macOS**:
  1. Ensure `setup.sh` is executable:
     ```bash
     chmod +x setup.sh
     ```
  2. Run the script:
     ```bash
     ./setup.sh
     ```
  3. The script:
     - Creates a virtual environment (`venv`).
     - Upgrades `pip`.
     - Installs dependencies from `requirements.txt`.
     - Attempts to install Tesseract OCR (if not already installed).

- **Windows**:
  1. Run the script in Command Prompt or PowerShell:
     ```bat
     setup.bat
     ```
  2. The script:
     - Creates a virtual environment (`venv`).
     - Upgrades `pip`.
     - Installs dependencies from `requirements.txt`.
     - Downloads and installs Tesseract OCR (if not already installed).

### Step 5: Install Tesseract OCR (Optional)
Tesseract is required for processing image files (`.jpg`, `.jpeg`, `.png`, `.bmp`, `.tiff`). The setup scripts attempt to install it, but if they fail, install manually:

- **Linux**:
  ```bash
  sudo apt-get update
  sudo apt-get install tesseract-ocr
  ```
- **macOS**:
  Install Homebrew if not already installed:
  ```bash
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  ```
  Then install Tesseract:
  ```bash
  brew install tesseract
  ```
- **Windows**:
  Download the installer from `https://github.com/UB-Mannheim/tesseract/releases` (e.g., `tesseract-ocr-w64-setup-5.4.0.20240606.exe`).
  Install and add Tesseract to the system PATH (default: `C:\Program Files\Tesseract-OCR`).

Verify Tesseract installation:
```bash
tesseract --version
```

### Step 6: Configure `config.yaml`
The `config.yaml` file contains settings for the API. Check and update if needed:
- **LM Studio URL**: Ensure `llm.url` matches the LM Studio server (default: `http://localhost:1234/v1/chat/completions`).
- **Timeout**: Increase `llm.timeout` (e.g., to `120`) if summarization requests time out.
- **Max File Size**: Adjust `app.max_file_size_mb` if processing large files.
Example:
```yaml
llm:
  url: "http://localhost:1234/v1/chat/completions"
  timeout: 60
app:
  max_file_size_mb: 100
```

### Step 7: Verify Setup
1. Activate the virtual environment:
   - Linux/macOS: `source venv/bin/activate`
   - Windows: `venv\Scripts\activate`
2. Ensure LM Studio is running with the model loaded.
3. Start the API to verify:
   ```bash
   uvicorn src.main:app --host 0.0.0.0 --port 8000
   ```
4. Check `app.log` for startup errors (e.g., LM Studio not running, missing `config.yaml`).

## Usage
1. Activate the virtual environment:
   - Linux/macOS: `source venv/bin/activate`
   - Windows: `venv\Scripts\activate`
2. Run the API:
   ```bash
   uvicorn src.main:app --host 0.0.0.0 --port 8000
   ```
3. Access the API:
   - Swagger UI: `http://localhost:8000/docs`
   - Endpoints:
     - `POST /extract-content/`: Extract content and metadata from files in a folder.
     - `POST /summarise/`: Generate 10-bullet-point summaries for files in a folder.
   - Example request:
     ```bash
     curl -X POST "http://localhost:8000/summarise/" -H "Content-Type: application/json" -d '{"folder_path": "/path/to/folder"}'
     ```

## Example Output
- `/extract-content/` (Success):
  ```json
  [
    {
      "filename": "example.pdf",
      "extension": ".pdf",
      "content": "Sample text...",
      "metadata": {
        "file_size_bytes": 123456,
        "created_at": "2025-07-12T10:50:00",
        "modified_at": "2025-07-12T10:50:00",
        "file_path": "/path/to/example.pdf"
      },
      "status": "success"
    }
  ]
  ```
- `/extract-content/` (Failure):
  ```json
  [
    {
      "filename": "example.pdf",
      "extension": ".pdf",
      "content": null,
      "metadata": null,
      "status": "failed: Permission denied accessing example.pdf"
    },
    {
      "filename": "invalid.xyz",
      "extension": ".xyz",
      "content": null,
      "metadata": null,
      "status": "failed: Unsupported extension .xyz. Supported: .bmp, .doc, .docx, .eml, .jpg, .jpeg, .pdf, .png, .ppt, .pptx, .tiff, .txt"
    }
  ]
  ```
- `/summarise/` (Success):
  ```json
  [
    {
      "filename": "example.pdf",
      "summary": [
        "1. First point",
        "2. Second point",
        ...
        "10. Tenth point"
      ],
      "status": "success"
    }
  ]
  ```
- `/summarise/` (Failure):
  ```json
  [
    {
      "filename": "example.pdf",
      "summary": [],
      "status": "failed: LLM server unavailable or failed to generate summary. Check app.log for details."
    },
    {
      "filename": ".DS_Store",
      "summary": [],
      "status": "skipped: Hidden or temporary file"
    }
  ]
  ```

## Troubleshooting
- **LM Studio Errors**:
  - **404 Not Found**: Ensure LM Studio is running and the server is started (default: `http://localhost:1234`). Verify `llm.url` in `config.yaml`.
  - **Timeout**: Increase `llm.timeout` in `config.yaml` (e.g., to `120`) or reduce system load. Check LM Studio logs for issues.
  - **Model Not Loaded**: Ensure Meta-Llama-3-8B-Instruct-GGUF is loaded in LM Studio.
  - Test the server:
    ```bash
    curl http://localhost:1234/v1/chat/completions -H "Content-Type: application/json" -d '{"model": "Meta-Llama-3-8B-Instruct-GGUF", "messages": [{"role": "user", "content": "Test"}]}'
    ```
- **File Processing Errors**:
  - **Permission Denied**: Ensure the API has read access to the folder/files. Run with appropriate permissions (e.g., `sudo` on Linux if needed).
  - **Corrupted Files**: Replace corrupted files (e.g., PDFs, images).
  - **Temporary/Hidden Files**: Files like `~$example.docx` or `.DS_Store` are skipped automatically.
  - **Unsupported Extensions**: Only `.pdf`, `.ppt`, `.pptx`, `.doc`, `.docx`, `.txt`, `.eml`, `.jpg`, `.jpeg`, `.png`, `.bmp`, `.tiff` are supported.
- **Image Processing**:
  - Install Tesseract OCR for image support. If unavailable, image processing is skipped (check `app.log`).
  - Ensure images are not corrupted and are in supported formats.
- **Configuration Errors**:
  - If `config.yaml` is missing or invalid, ensure it exists in the project directory with required sections (`app`, `logging`, `threading`, `llm`).
- **Setup Issues**:
  - **Python Not Found**: Install Python 3.8+ and ensure it’s in the system PATH.
  - **Tesseract Installation Failed**: Manually install Tesseract (see Step 5) or skip image processing.
  - **Dependency Installation Failed**: Check `requirements.txt` and internet connection. Run `pip install -r requirements.txt` manually.
- **Logs**: Check `app.log` for detailed error messages and instructions.
```