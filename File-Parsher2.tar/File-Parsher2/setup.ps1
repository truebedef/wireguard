# Requires -Version 5.0
<#+
.SYNOPSIS
    Setup script for File Content Extractor API (PowerShell)
.DESCRIPTION
    1. Ensures Python 3.8+ is installed (installs via winget if missing)
    2. Ensures Tesseract OCR is installed for image processing (optional)
    3. Creates and activates a virtual environment
    4. Upgrades pip and installs requirements from requirements.txt
    5. Displays instructions for running the API
#>

Write-Host "Setting up File Content Extractor API..." -ForegroundColor Cyan

# Helper function to test command existence
function Test-Command {
    param([Parameter(Mandatory)][string]$Name)
    $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

# Ensure winget is available
if (-not (Test-Command 'winget')) {
    Write-Warning 'winget not found. Please install Python 3.8+ and Tesseract OCR manually.'
} else {
    # Install Python if needed
    if (-not (Test-Command 'python')) {
        Write-Host 'Python not found. Installing via winget...' -ForegroundColor Yellow
        winget install --exact --id Python.Python.3 -h || (
            Write-Warning 'winget failed to install Python. Install manually and re-run.'; exit 1)
    }

    # Install Tesseract if needed
    if (-not (Test-Command 'tesseract')) {
        Write-Host 'Tesseract not found. Installing via winget...' -ForegroundColor Yellow
        winget install --exact --id UB-Mannheim.TesseractOCR -h || Write-Warning 'Failed to install Tesseract via winget. Image OCR features will be unavailable until installed.'
    }
}

# Ensure python is available after potential install
if (-not (Test-Command 'python')) {
    Write-Error 'Python executable not found in PATH. Aborting.'
    exit 1
}

# Create virtual environment
if (-Not (Test-Path 'venv')) {
    python -m venv venv
}

# Activate venv in current session
$venvActivate = Join-Path -Path (Resolve-Path 'venv').Path -ChildPath 'Scripts\Activate.ps1'
& $venvActivate

# Upgrade pip and install requirements
pip install --upgrade pip
pip install -r requirements.txt

Write-Host "Setup complete! Ensure LM Studio is running with Meta-Llama-3-8B-Instruct-GGUF model." -ForegroundColor Green
Write-Host "Run the API with: `n`$env:VIRTUAL_ENV\Scripts\Activate.ps1; uvicorn src.main:app --host 0.0.0.0 --port 8000"
