#!/usr/bin/env python3
"""
Universal Python Bootstrapper for File Content Extractor API
- Works on Windows, macOS, Linux (Python 3.6+ required)
- Installs pip, venv, requirements, and attempts to install system dependencies (where possible)
- Provides clear instructions for manual steps if automation fails
"""
import os
import sys
import subprocess
import shutil
import platform

BOLD_GREEN = '\033[1;32m'
BOLD_RED = '\033[1;31m'
BOLD_YELLOW = '\033[1;33m'
RESET = '\033[0m'


def info(msg):
    print(f"{BOLD_GREEN}{msg}{RESET}")

def warn(msg):
    print(f"{BOLD_YELLOW}WARNING: {msg}{RESET}")

def die(msg):
    print(f"{BOLD_RED}ERROR: {msg}{RESET}")
    sys.exit(1)

def run(cmd, check=True, shell=False, **kwargs):
    info(f"$ {' '.join(cmd) if isinstance(cmd, list) else cmd}")
    try:
        subprocess.run(cmd, check=check, shell=shell, **kwargs)
    except subprocess.CalledProcessError as e:
        warn(f"Command failed: {e}")
        if check:
            sys.exit(1)

def ensure_python():
    if sys.version_info < (3, 6):
        die("Python 3.6+ is required.")
    info(f"Python version: {platform.python_version()}")

def ensure_pip():
    try:
        import pip
    except ImportError:
        info("pip not found. Attempting to install pip...")
        run([sys.executable, '-m', 'ensurepip', '--upgrade'], check=False)
        try:
            import pip
        except ImportError:
            die("pip could not be installed. Please install pip manually.")

def ensure_venv():
    if not shutil.which('python3') and not shutil.which('python'):
        die("Python 3 is not available in PATH.")
    if not hasattr(sys, 'base_prefix'):
        die("Python venv module is missing. Please install python3-venv or equivalent.")
    if not os.path.isdir('venv'):
        info("Creating virtual environment...")
        run([sys.executable, '-m', 'venv', 'venv'])
    else:
        info("Virtual environment already exists.")

def activate_venv():
    activate_script = os.path.join('venv', 'Scripts', 'activate_this.py') if os.name == 'nt' else os.path.join('venv', 'bin', 'activate_this.py')
    if os.path.exists(activate_script):
        with open(activate_script) as f:
            exec(f.read(), dict(__file__=activate_script))
        info("Virtual environment activated.")
    else:
        warn("Could not auto-activate venv in this shell. Please activate manually if needed.")

def upgrade_pip():
    run([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'])

def install_requirements():
    if os.path.isfile('requirements.txt'):
        run([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])
    else:
        warn("requirements.txt not found. Skipping Python dependency installation.")

def try_install_system_deps():
    sys_deps = {
        'Linux': [
            ('apt-get', ['sudo', 'apt-get', 'update']),
            ('apt-get', ['sudo', 'apt-get', 'install', '-y', 'git', 'python3-venv', 'python3-pip', 'build-essential', 'tesseract-ocr']),
            ('dnf', ['sudo', 'dnf', 'install', '-y', 'git', 'python3', 'python3-venv', 'python3-pip', 'tesseract']),
            ('yum', ['sudo', 'yum', 'install', '-y', 'git', 'python3', 'python3-venv', 'python3-pip', 'tesseract']),
            ('pacman', ['sudo', 'pacman', '-S', '--noconfirm', 'git', 'python', 'python-pip', 'tesseract']),
            ('zypper', ['sudo', 'zypper', 'install', '-y', 'git', 'python3', 'python3-venv', 'python3-pip', 'tesseract-ocr']),
        ],
        'Darwin': [
            ('brew', ['brew', 'install', 'git', 'python3', 'tesseract'])
        ],
        'Windows': [
            ('choco', ['choco', 'install', '-y', 'git', 'python', 'tesseract']),
            ('winget', ['winget', 'install', '--silent', '--accept-package-agreements', '--accept-source-agreements', 'Git.Git', 'Python.Python.3', 'UB-Mannheim.TesseractOCR'])
        ]
    }
    plat = platform.system()
    attempted = False
    if plat in sys_deps:
        for mgr, cmd in sys_deps[plat]:
            if shutil.which(mgr):
                info(f"Attempting to install system dependencies using {mgr}...")
                run(cmd, check=False)
                attempted = True
                break
    if not attempted:
        warn(f"Could not auto-install system dependencies for {plat}. Please install git, python3, pip, and tesseract manually.")

def main():
    ensure_python()
    try_install_system_deps()
    ensure_pip()
    ensure_venv()
    activate_venv()
    upgrade_pip()
    install_requirements()
    info("Setup complete! Ensure LM Studio is running with Meta-Llama-3-8B-Instruct-GGUF model.")
    info("To activate your venv: \n  source venv/bin/activate   # Linux/macOS\n  venv\\Scripts\\activate    # Windows\nThen run: uvicorn src.main:app --host 0.0.0.0 --port 8000")

if __name__ == '__main__':
    main()
