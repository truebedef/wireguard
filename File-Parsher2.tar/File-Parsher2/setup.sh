#!/bin/bash
set -euo pipefail

bold_green='\033[1;32m'
bold_red='\033[1;31m'
bold_yellow='\033[1;33m'
reset='\033[0m'

function die() {
    echo -e "${bold_red}ERROR:${reset} $1"
    exit 1
}

function warn() {
    echo -e "${bold_yellow}WARNING:${reset} $1"
}

function info() {
    echo -e "${bold_green}$1${reset}"
}

echo "Setting up File Content Extractor API..."

OS="$(uname -s)"

# Detect OS and package manager
if [[ "$OS" == "Linux" ]]; then
    if command -v apt-get >/dev/null 2>&1; then
        PKG="sudo apt-get install -y"
        UPDATE="sudo apt-get update -y"
        UPGRADE="sudo apt-get upgrade -y"
        PYTHON="python3"
        PIP="pip3"
        TESS="tesseract-ocr"
    elif command -v dnf >/dev/null 2>&1; then
        PKG="sudo dnf install -y"
        UPDATE="sudo dnf check-update -y"
        UPGRADE="sudo dnf upgrade -y"
        PYTHON="python3"
        PIP="pip3"
        TESS="tesseract"
    elif command -v yum >/dev/null 2>&1; then
        PKG="sudo yum install -y"
        UPDATE="sudo yum check-update -y"
        UPGRADE="sudo yum upgrade -y"
        PYTHON="python3"
        PIP="pip3"
        TESS="tesseract"
    elif command -v pacman >/dev/null 2>&1; then
        PKG="sudo pacman -S --noconfirm"
        UPDATE="sudo pacman -Sy"
        UPGRADE="sudo pacman -Syu --noconfirm"
        PYTHON="python"
        PIP="pip"
        TESS="tesseract"
    elif command -v zypper >/dev/null 2>&1; then
        PKG="sudo zypper install -y"
        UPDATE="sudo zypper refresh"
        UPGRADE="sudo zypper update -y"
        PYTHON="python3"
        PIP="pip3"
        TESS="tesseract-ocr"
    else
        die "Unsupported Linux distribution. Please install Python 3, pip, git, and Tesseract OCR manually."
    fi
elif [[ "$OS" == "Darwin" ]]; then
    if ! command -v brew >/dev/null 2>&1; then
        warn "Homebrew not found. Installing Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || die "Failed to install Homebrew. Install manually from https://brew.sh/ and re-run."
    fi
    PKG="brew install"
    UPDATE="brew update"
    UPGRADE="brew upgrade"
    PYTHON="python3"
    PIP="pip3"
    TESS="tesseract"
elif [[ "$OS" =~ MINGW|MSYS|CYGWIN ]]; then
    if command -v choco >/dev/null 2>&1; then
        PKG="choco install -y"
        UPDATE=":"
        UPGRADE=":"
        PYTHON="python"
        PIP="pip"
        TESS="tesseract"
    elif command -v winget >/dev/null 2>&1; then
        PKG="winget install --silent --accept-package-agreements --accept-source-agreements"
        UPDATE=":"
        UPGRADE=":"
        PYTHON="python"
        PIP="pip"
        TESS="tesseract"
    else
        die "No supported package manager found (choco/winget). Install Python, pip, git, and Tesseract OCR manually."
    fi
else
    die "Unsupported OS: $OS. Please install dependencies manually."
fi

info "Updating package lists..."
$UPDATE || warn "Failed to update package lists. Continuing..."
info "Upgrading packages..."
$UPGRADE || warn "Failed to upgrade some packages. Continuing..."

info "Installing core dependencies..."
$PKG git || warn "Failed to install git. Please install manually."
$PKG $PYTHON || warn "Failed to install Python. Please install manually."
$PKG $PIP || warn "Failed to install pip. Please install manually."
$PKG $TESS || warn "Failed to install Tesseract OCR. Image/PDF OCR features will be unavailable."
if [[ "$OS" == "Linux" ]]; then
    $PKG python3-venv || warn "Failed to install python3-venv. Some features may not work."
    $PKG build-essential || warn "Failed to install build-essential. Some dependencies may fail to build."
fi

# Check for Python
if ! command -v $PYTHON >/dev/null 2>&1; then
    die "$PYTHON not found after install. Please install Python 3.8+ manually."
fi

# Check for pip
if ! command -v $PIP >/dev/null 2>&1; then
    die "$PIP not found after install. Please install pip manually."
fi

# Create virtual environment
if [ ! -d "venv" ]; then
    info "Creating Python virtual environment..."
    $PYTHON -m venv venv || die "Failed to create virtual environment."
else
    info "Virtual environment already exists."
fi

# Activate venv
source venv/bin/activate || die "Failed to activate virtual environment."

# Upgrade pip
info "Upgrading pip..."
pip install --upgrade pip || die "Failed to upgrade pip."

# Install Python requirements
if [ -f requirements.txt ]; then
    info "Installing Python dependencies from requirements.txt..."
    pip install -r requirements.txt || die "Failed to install Python dependencies."
else
    warn "requirements.txt not found. Skipping Python dependency installation."
fi

info "Setup complete! Ensure LM Studio is running with Meta-Llama-3-8B-Instruct-GGUF model."
echo -e "Run the API with: ${bold_green}source venv/bin/activate && uvicorn src.main:app --host 0.0.0.0 --port 8000${reset}"

# Check for python3
if ! command -v python3 >/dev/null 2>&1; then
    die "python3 not found after install. Please install Python 3.8+ manually."
fi

# Check for pip
if ! command -v pip3 >/dev/null 2>&1; then
    die "pip3 not found after install. Please install pip manually."
fi

# Install Tesseract OCR for image and PDF processing (optional)
info "Checking for Tesseract OCR..."
if ! command -v tesseract >/dev/null 2>&1; then
    info "Installing Tesseract OCR..."
    sudo apt-get install -y tesseract-ocr || warn "Failed to install Tesseract OCR. Image/PDF OCR features will be unavailable."
else
    info "Tesseract OCR is already installed."
fi

# Create virtual environment
if [ ! -d "venv" ]; then
    info "Creating Python virtual environment..."
    python3 -m venv venv || die "Failed to create virtual environment."
else
    info "Virtual environment already exists."
fi

# Activate venv
source venv/bin/activate || die "Failed to activate virtual environment."

# Upgrade pip
info "Upgrading pip..."
pip install --upgrade pip || die "Failed to upgrade pip."

# Install Python requirements
if [ -f requirements.txt ]; then
    info "Installing Python dependencies from requirements.txt..."
    pip install -r requirements.txt || die "Failed to install Python dependencies."
else
    warn "requirements.txt not found. Skipping Python dependency installation."
fi

info "Setup complete! Ensure LM Studio is running with Meta-Llama-3-8B-Instruct-GGUF model."
echo -e "Run the API with: ${bold_green}source venv/bin/activate && uvicorn src.main:app --host 127.0.0.1 --port 8000${reset}"