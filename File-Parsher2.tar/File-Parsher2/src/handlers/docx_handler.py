from pathlib import Path
import docx
from typing import Optional

class DOCXHandler:
    """Handles processing of DOC/DOCX files."""
    
    def process(self, file_path: Path) -> Optional[str]:
        """Extract text from a DOC/DOCX file."""
        try:
            doc = docx.Document(file_path)
            text = ""
            for para in doc.paragraphs:
                text += para.text + "\n"
            return text.strip() if text else None
        except Exception as e:
            raise ValueError(f"Error processing DOC/DOCX {file_path.name}: {str(e)}")