from pathlib import Path
from pptx import Presentation
from typing import Optional

class PPTHandler:
    """Handles processing of PPT/PPTX files."""
    
    def process(self, file_path: Path) -> Optional[str]:
        """Extract text from a PPT/PPTX file."""
        try:
            prs = Presentation(file_path)
            text = ""
            for slide in prs.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        text += shape.text + "\n"
            return text.strip() if text else None
        except Exception as e:
            raise ValueError(f"Error processing PPT/PPTX {file_path.name}: {str(e)}")