from pathlib import Path
import PyPDF2
from typing import Optional

class PDFHandler:
    """Handles processing of PDF files."""
    
    def process(self, file_path: Path) -> Optional[str]:
        """Extract text from a PDF file."""
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""
                for page in pdf_reader.pages:
                    extracted = page.extract_text()
                    if extracted:
                        text += extracted
                return text.strip() if text else None
        except Exception as e:
            raise ValueError(f"Error processing PDF {file_path.name}: {str(e)}")