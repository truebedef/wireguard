from pathlib import Path
from PIL import Image
import pytesseract
from typing import Optional
import logging

class ImageHandler:
    """Handles processing of image files (JPG, JPEG, PNG, BMP, TIFF) using OCR."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.supported_formats = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
    
    def process(self, file_path: Path) -> Optional[str]:
        """Extract text from an image file using OCR."""
        try:
            if file_path.suffix.lower() not in self.supported_formats:
                raise ValueError(f"Unsupported image format: {file_path.suffix}")
            try:
                image = Image.open(file_path)
            except Exception as e:
                raise ValueError(f"Failed to open image {file_path.name}: Corrupted or invalid image ({str(e)})")
            try:
                text = pytesseract.image_to_string(image)
                if not text.strip():
                    self.logger.warning(f"No text extracted from image {file_path.name}")
                    return None
                return text.strip()
            except pytesseract.TesseractNotFoundError:
                self.logger.warning(
                    f"Tesseract OCR not found. Install Tesseract to enable image processing. "
                    f"Skipping {file_path.name}. See README for installation instructions."
                )
                return None
            except pytesseract.TesseractError as e:
                raise ValueError(f"Tesseract OCR error for {file_path.name}: {str(e)}")
            except MemoryError:
                raise ValueError(f"Image {file_path.name} too large to process: Out of memory")
        except Exception as e:
            raise ValueError(f"Error processing image {file_path.name}: {str(e)}")