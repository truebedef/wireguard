from pathlib import Path
from typing import Optional

class TXTHandler:
    """Handles processing of TXT files."""
    
    def process(self, file_path: Path) -> Optional[str]:
        """Extract text from a TXT file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
                return text.strip() if text else None
        except Exception as e:
            raise ValueError(f"Error processing TXT {file_path.name}: {str(e)}")