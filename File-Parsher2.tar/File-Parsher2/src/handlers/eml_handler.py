from pathlib import Path
from email import policy
from email.parser import BytesParser
from bs4 import BeautifulSoup
from typing import Optional
import json

class EMLHandler:
    """Handles processing of EML files."""
    
    def process(self, file_path: Path) -> Optional[str]:
        """Extract text and metadata from an EML file."""
        try:
            with open(file_path, 'rb') as file:
                msg = BytesParser(policy=policy.default).parse(file)
            text = ""
            subject = msg['subject'] if msg['subject'] else ""
            if msg.is_multipart():
                for part in msg.walk():
                    content_type = part.get_content_type()
                    if content_type == 'text/plain':
                        text += part.get_content() + "\n"
                    elif content_type == 'text/html':
                        html_content = part.get_content()
                        soup = BeautifulSoup(html_content, 'html.parser')
                        text += soup.get_text(separator=' ', strip=True) + "\n"
            else:
                content_type = msg.get_content_type()
                if content_type == 'text/plain':
                    text += msg.get_content() + "\n"
                elif content_type == 'text/html':
                    html_content = msg.get_content()
                    soup = BeautifulSoup(html_content, 'html.parser')
                    text += soup.get_text(separator=' ', strip=True) + "\n"
            if not text.strip() and subject:
                text = subject
            return json.dumps({
                "sender": msg['from'],
                "receiver": msg['to'],
                "subject": subject,
                "body": text.strip()
            })
        except Exception as e:
            raise ValueError(f"Error processing EML {file_path.name}: {str(e)}")