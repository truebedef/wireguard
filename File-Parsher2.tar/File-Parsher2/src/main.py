import os
import logging
from pathlib import Path
from typing import Dict, List
from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel
import yaml
from concurrent.futures import ThreadPoolExecutor
from .file_processor import FileProcessor, FileProcessingError
from .llm import LLMClient
import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Load configuration
try:
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
    if not config or not isinstance(config, dict):
        raise ValueError("Invalid or empty config.yaml")
except FileNotFoundError:
    logger.error("config.yaml not found in project directory")
    raise
except yaml.YAMLError as e:
    logger.error(f"Error parsing config.yaml: {str(e)}")
    raise

# Validate configuration
required_config_keys = ["app", "logging", "threading", "llm"]
for key in required_config_keys:
    if key not in config:
        logger.error(f"Missing required section '{key}' in config.yaml")
        raise ValueError(f"Missing required section '{key}' in config.yaml")

app = FastAPI(title="File Content Extractor API")
try:
    file_processor = FileProcessor(config)
    llm_client = LLMClient(config)
except Exception as e:
    logger.error(f"Failed to initialize application: {str(e)}")
    raise

executor = ThreadPoolExecutor(max_workers=config["threading"].get("max_workers", 4))

class FolderInput(BaseModel):
    folder_path: str

def process_single_file(filename: str, folder_path: str) -> Dict:
    """Process a single file and return its content and metadata."""
    file_path = Path(folder_path) / filename
    try:
        if filename.startswith("~$") or filename.startswith("."):
            logger.warning(f"Skipping hidden or temporary file {filename}")
            return {
                "filename": filename,
                "extension": file_path.suffix.lower(),
                "content": None,
                "metadata": None,
                "status": "skipped: Hidden or temporary file"
            }
        file_extension = file_path.suffix.lower()
        if file_extension not in config["app"]["allowed_extensions"]:
            return {
                "filename": filename,
                "extension": file_extension,
                "content": None,
                "metadata": None,
                "status": f"failed: Unsupported extension {file_extension}. Supported: {', '.join(sorted(config['app']['allowed_extensions']))}"
            }
        content = file_processor.process_file(file_path)
        file_stats = file_path.stat()
        metadata = {
            "file_size_bytes": file_stats.st_size,
            "created_at": datetime.datetime.fromtimestamp(file_stats.st_ctime).isoformat(),
            "modified_at": datetime.datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
            "file_path": str(file_path.resolve())
        }
        return {
            "filename": filename,
            "extension": file_extension,
            "content": content,
            "metadata": metadata,
            "status": "success"
        }
    except FileProcessingError as e:
        return {
            "filename": filename,
            "extension": file_path.suffix.lower(),
            "content": None,
            "metadata": None,
            "status": f"failed: {str(e)}"
        }
    except Exception as e:
        logger.error(f"Unexpected error processing {filename}: {str(e)}")
        return {
            "filename": filename,
            "extension": file_path.suffix.lower(),
            "content": None,
            "metadata": None,
            "status": f"failed: Unexpected error: {str(e)}"
        }

def summarize_single_file(filename: str, folder_path: str) -> Dict:
    """Summarize a single file using the LLM."""
    file_path = Path(folder_path) / filename
    try:
        if filename.startswith("~$") or filename.startswith("."):
            logger.warning(f"Skipping hidden or temporary file {filename}")
            return {
                "filename": filename,
                "summary": [],
                "status": "skipped: Hidden or temporary file"
            }
        file_extension = file_path.suffix.lower()
        if file_extension not in config["app"]["allowed_extensions"]:
            return {
                "filename": filename,
                "summary": [],
                "status": f"failed: Unsupported extension {file_extension}. Supported: {', '.join(sorted(config['app']['allowed_extensions']))}"
            }
        content = file_processor.process_file(file_path)
        if not content or not content.strip():
            return {
                "filename": filename,
                "summary": [],
                "status": f"failed: No valid content extracted from {filename}"
            }
        logger.info(f"Starting summarization for {filename}")
        summary = llm_client.summarize(filename, content)
        logger.info(f"Completed summarization for {filename}")
        return {
            "filename": filename,
            "summary": summary if summary else [],
            "status": "success" if summary else "failed: LLM server unavailable or failed to generate summary. Check app.log for details."
        }
    except FileProcessingError as e:
        return {
            "filename": filename,
            "summary": [],
            "status": f"failed: {str(e)}"
        }
    except Exception as e:
        logger.error(f"Unexpected error summarizing {filename}: {str(e)}")
        return {
            "filename": filename,
            "summary": [],
            "status": f"failed: Unexpected error: {str(e)}"
        }

@app.post("/extract-content/", response_model=List[Dict])
async def extract_folder_content(folder: FolderInput):
    """Extract content from all supported files in a folder."""
    folder_path = Path(folder.folder_path)
    try:
        if not folder_path.exists():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Folder {folder_path} does not exist")
        if not folder_path.is_dir():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Path {folder_path} is not a directory")
        try:
            os.access(folder_path, os.R_OK)
        except OSError:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"Permission denied accessing folder {folder_path}")
        
        files = [f for f in os.listdir(folder_path) if (folder_path / f).is_file()]
        if not files:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No files found in folder")
        
        # Process files concurrently
        results = []
        futures = [executor.submit(process_single_file, f, folder_path) for f in files]
        for future in futures:
            try:
                results.append(future.result())
            except Exception as e:
                logger.error(f"Error in thread for folder {folder_path}: {str(e)}")
                results.append({
                    "filename": "unknown",
                    "extension": "",
                    "content": None,
                    "metadata": None,
                    "status": f"failed: Thread error: {str(e)}"
                })
        return results
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing folder {folder_path}: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error processing folder: {str(e)}. Please check the folder path and try again.")

@app.post("/summarise/", response_model=List[Dict])
async def summarise_folder_content(folder: FolderInput):
    """Summarize content from all supported files in a folder sequentially."""
    folder_path = Path(folder.folder_path)
    try:
        if not folder_path.exists():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Folder {folder_path} does not exist")
        if not folder_path.is_dir():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Path {folder_path} is not a directory")
        try:
            os.access(folder_path, os.R_OK)
        except OSError:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"Permission denied accessing folder {folder_path}")
        
        files = [f for f in os.listdir(folder_path) if (folder_path / f).is_file()]
        if not files:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No files found in folder")
        
        # Process files sequentially
        results = []
        for f in files:
            logger.info(f"Processing file {f} sequentially")
            result = summarize_single_file(f, folder_path)
            results.append(result)
        return results
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error summarizing folder {folder_path}: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error summarizing folder: {str(e)}. Please check the folder path and try again.")

if __name__ == "__main__":
    import uvicorn
    try:
        uvicorn.run(app, host="127.0.0.1", port=8000)
    except Exception as e:
        logger.error(f"Failed to start API server: {str(e)}")
        raise