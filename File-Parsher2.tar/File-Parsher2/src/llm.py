import requests
from typing import List, Optional
import logging
import time
import json
from typing import Dict

class LLMClient:
    """Client for interacting with LM Studio's local API."""
    
    def __init__(self, config: Dict):
        self.logger = logging.getLogger(__name__)
        self.url = config["llm"].get("url", "http://localhost:1234/v1/chat/completions")
        self.model = config["llm"].get("model", "Meta-Llama-3-8B-Instruct-GGUF")
        self.max_tokens = config["llm"].get("max_tokens", 500)
        self.temperature = config["llm"].get("temperature", 0.7)
        self.retries = config["llm"].get("retries", 3)
        self.timeout = config["llm"].get("timeout", 60)
        self.retry_delay = config["llm"].get("retry_delay", 2)
        # Maximum characters from file content to include in a single prompt
        self.max_content_chars = config["llm"].get("max_content_chars", 10000)
        self._check_server()
    
    def _check_server(self):
        """Check if the LM Studio server and model are available."""
        try:
            # Check if server is running
            response = requests.get(self.url.replace("/chat/completions", "/model"), timeout=5)
            response.raise_for_status()
            # Check if model is available (LM Studio may not expose model list, so test with a small request)
            test_payload = {
                "model": self.model,
                "messages": [{"role": "user", "content": "Test"}],
                "max_tokens": 10
            }
            response = requests.post(self.url, json=test_payload, timeout=5)
            response.raise_for_status()
            self.logger.info(f"LM Studio server available at {self.url} with model {self.model}")
        except requests.exceptions.ConnectionError:
            self.logger.error(
                f"Cannot connect to LM Studio server at {self.url}. "
                "Ensure LM Studio is running and the server is started (default port: 1234). "
                "Check network settings or update 'llm.url' in config.yaml."
            )
        except requests.exceptions.HTTPError as e:
            if response.status_code == 404:
                self.logger.error(
                    f"LM Studio endpoint {self.url} not found. "
                    "Verify the server is running and the URL is correct in config.yaml."
                )
            elif response.status_code == 400:
                self.logger.error(
                    f"Model {self.model} not loaded in LM Studio. "
                    "Ensure Meta-Llama-3-8B-Instruct-GGUF is loaded. Check LM Studio settings."
                )
            else:
                self.logger.error(
                    f"LM Studio server error: {str(e)}. "
                    "Check LM Studio logs and ensure sufficient system resources (CPU, memory)."
                )
        except requests.exceptions.RequestException as e:
            self.logger.error(
                f"Failed to connect to LM Studio at {self.url}: {str(e)}. "
                "Ensure LM Studio is running and check config.yaml for correct URL and model."
            )
    
    def summarize(self, filename: str, content: str) -> Optional[List[str]]:
        """Generate a 10-bullet-point summary using LM Studio."""
        if not content or not content.strip():
            self.logger.warning(f"No valid content to summarize for {filename}")
            return None
        # Truncate content to avoid exceeding LLM context window
        truncated_content = content[: self.max_content_chars]
        prompt = (
            "You are a helpful assistant that summarizes content into exactly 10 concise bullet points with numbering (1. to 10.). "
            "Use only the provided extracted content to generate the summary, and do not include any external information. "
            f"Summarize the following content from file {filename}:\n{truncated_content}"
        )
        headers = {"Content-Type": "application/json"}
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": self.max_tokens,
            "temperature": self.temperature
        }
        
        for attempt in range(self.retries):
            try:
                response = requests.post(self.url, json=payload, headers=headers, timeout=self.timeout)
                response.raise_for_status()
                try:
                    response_json = response.json()
                    summary = response_json["choices"][0]["message"]["content"].strip()
                except (KeyError, ValueError, json.JSONDecodeError) as e:
                    self.logger.error(f"Malformed response from LM Studio for {filename}: {str(e)}")
                    return None
                # Parse summary into list of bullet points
                lines = [line.strip() for line in summary.split("\n") if line.strip().startswith(("1. ", "2. ", "3. ", "4. ", "5. ", "6. ", "7. ", "8. ", "9. ", "10. "))]
                if len(lines) != 10:
                    self.logger.warning(f"Summary for {filename} has {len(lines)} bullet points, expected 10")
                return lines[:10] if lines else None
            except requests.exceptions.ConnectionError as e:
                self.logger.error(
                    f"Attempt {attempt + 1}/{self.retries} failed for {filename}: "
                    f"Connection error to LM Studio at {self.url}. Ensure server is running. ({str(e)})"
                )
            except requests.exceptions.Timeout as e:
                self.logger.error(
                    f"Attempt {attempt + 1}/{self.retries} failed for {filename}: "
                    f"Request timed out after {self.timeout}s. Increase 'llm.timeout' in config.yaml or check server load. ({str(e)})"
                )
            except requests.exceptions.HTTPError as e:
                self.logger.error(
                    f"Attempt {attempt + 1}/{self.retries} failed for {filename}: "
                    f"HTTP error {response.status_code}. "
                    f"Check LM Studio logs and ensure model {self.model} is loaded. ({str(e)})"
                )
            except requests.exceptions.RequestException as e:
                self.logger.error(
                    f"Attempt {attempt + 1}/{self.retries} failed for {filename}: {str(e)}"
                )
            if attempt < self.retries - 1:
                delay = self.retry_delay * (2 ** attempt)  # Exponential backoff
                self.logger.info(f"Retrying in {delay}s...")
                time.sleep(delay)
        self.logger.error(
            f"Failed to summarize {filename} after {self.retries} attempts. "
            "Ensure LM Studio is running with model {self.model} and check 'llm.url' in config.yaml."
        )
        return None