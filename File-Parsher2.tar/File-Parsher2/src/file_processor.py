from pathlib import Path
from typing import Optional, Dict
from .handlers.pdf_handler import PDFHandler
from .handlers.ppt_handler import PPTHandler
from .handlers.docx_handler import DOCXHandler
from .handlers.txt_handler import TXTHandler
from .handlers.eml_handler import EMLHandler
from .handlers.image_handler import ImageHandler
import logging
import os

class FileProcessingError(Exception):
    """Custom exception for file processing errors."""
    pass

class FileProcessor:
    """Processes various file types to extract text content."""
    
    def __init__(self, config: Dict):
        self.logger = logging.getLogger(__name__)
        self.max_file_size = config["app"]["max_file_size_mb"] * 1024 * 1024
        self.handlers = {
            '.pdf': PDFHandler(),
            '.ppt': PPTHandler(),
            '.pptx': PPTHandler(),
            '.doc': DOCXHandler(),
            '.docx': DOCXHandler(),
            '.txt': TXTHandler(),
            '.eml': EMLHandler(),
            '.jpg': ImageHandler(),
            '.jpeg': ImageHandler(),
            '.png': ImageHandler(),
            '.bmp': ImageHandler(),
            '.tiff': ImageHandler()
        }
        self.allowed_extensions = set(config["app"]["allowed_extensions"])
    
    def process_file(self, file_path: str) -> Optional[str]:
        """Process a file based on its extension."""
        file_path = Path(file_path)
        try:
            if not file_path.exists():
                raise FileProcessingError(f"File {file_path} does not exist")
            if not file_path.is_file():
                raise FileProcessingError(f"Path {file_path} is not a file")
            if file_path.stat().st_size > self.max_file_size:
                raise FileProcessingError(
                    f"File {file_path.name} exceeds maximum size of {self.max_file_size // (1024 * 1024)} MB"
                )
            if file_path.name.startswith("~$") or file_path.name.startswith("."):
                raise FileProcessingError(f"Skipping hidden or temporary file {file_path.name}")
            if not os.access(file_path, os.R_OK):
                raise FileProcessingError(f"Permission denied accessing {file_path.name}")
            extension = file_path.suffix.lower()
            if extension not in self.allowed_extensions:
                raise FileProcessingError(
                    f"Unsupported extension {extension}. Supported extensions: {', '.join(sorted(self.allowed_extensions))}"
                )
            handler = self.handlers.get(extension)
            if not handler:
                raise FileProcessingError(f"No handler for extension {extension}")
            return handler.process(file_path)
        except FileProcessingError as e:
            self.logger.error(str(e))
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error processing {file_path.name}: {str(e)}")
            raise FileProcessingError(f"Unexpected error processing {file_path.name}: {str(e)}")